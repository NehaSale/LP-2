from scapy.all import sniff, IP, TCP, UDP																		# Import necessary functions and classes from the Scapy library

def packet_handler(packet):			 # Define a function to handle each captured packet

    if IP in packet: 		   				 # Check if the packet contains an IP layer header
        ip = packet[IP] 	      	 			 # Extract the IP layer header
        protocol = ip.proto        			 # Retrieve the protocol number from the IP header
        length = len(packet)	   		         # Calculate the length of the captured packet
        src_ip = ip.src      					 # Extract the source  IP address from the IP header
        dst_ip = ip.dst					# Extract the destination IP address from the IP header

        print(f"IP Packet: Source IP: {src_ip}, Destination IP: {dst_ip}, Protocol: {protocol}, Length: {length}")               	 # Print information about the captured IP packet

        if protocol == 6:        				# If the protocol is TCP

            tcp = packet[TCP]            		# Extract TCP header information

            src_port = tcp.sport             		# Get source port from the TCP header
            dst_port = tcp.dport            		# Get destination port from the TCP header
            print(f"  TCP Packet: Source Port: {src_port}, Destination Port: {dst_port}")           							 # Print information about the TCP packet

        elif protocol == 17:         			# If the protocol is UDP
            udp = packet[UDP]            		# Extract UDP header information

            src_port = udp.sport            		# Get source port from the UDP header
            dst_port = udp.dport            		# Get  destination port from the UDP header
            print(f"  UDP Packet: Source Port: {src_port}, Destination Port: {dst_port}")             						# Print information about the UDP packet

print("Sniffing packets... Press Ctrl+C to stop.")																# Print a message indicating that packet sniffing has started

									# Start sniffing packets using Scapy
									# Call the packet_handler function for each captured packet
									# Set store=0 to prevent storing captured packets in memory
sniff(prn=packet_handler, store=0)



#TO RUN COMMANDS ON UBUNTU

#Install Scapy: If you haven't already installed Scapy, you can do so using pip, the Python package manager. Open a terminal and run the following command:
#

#       sudo pip install scapy


#Copy the Script: Copy the provided Python script into a file, and name it as example = new_name.py.
#Run the Script: Open a terminal and navigate to the directory where the script is located cd "path-to-your-new_name.py-file". Then, run the script using Python:

#      python3 packet_sniffer.py
